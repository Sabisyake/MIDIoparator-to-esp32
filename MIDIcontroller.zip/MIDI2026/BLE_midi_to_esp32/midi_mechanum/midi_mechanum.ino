#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <freertos/semphr.h>
#include <ESP32Servo.h>

#define _DODAI 16
#define _Arm_1 16
#define _Arm_2 16
#define _HAND 16

Servo Dodai,Arm1,Arm2,Hand;


#define SERVICE_UUID           "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_RX "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_TX "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

enum MOTOR_ID { MOTOR_FL, MOTOR_BL, MOTOR_FR, MOTOR_BR };

constexpr uint8_t pins[] = {
  32, 33,   // FL
  22, 23,   // BL
  25, 26,   // FR
  27, 14    // BR
};

BLECharacteristic *txCharacteristic;
SemaphoreHandle_t speedMutex;

volatile bool deviceConnected = false;
volatile int stickX = 63;
volatile int stickY = 63;
int targetSpeed[4] = {0, 0, 0, 0};
int currentSpeed[4] = {999, 999, 999, 999};

void rotate(uint8_t ID, int speed) {
  speed = constrain(speed, -255, 255);
  ledcWrite(pins[ID * 2],     speed > 0 ?  speed : 0);
  ledcWrite(pins[ID * 2 + 1], speed < 0 ? -speed : 0);
}

int midiToSpeed(uint8_t value) {
  int diff = (int)value - 63;
  if (abs(diff) <= 4) return 0;
  int sign = diff > 0 ? 1 : -1;
  return sign * map(abs(diff), 4, 63, 0, 255);
}

void updateMecanum() {
  int x = midiToSpeed(stickX);
  int y = midiToSpeed(stickY);

  xSemaphoreTake(speedMutex, portMAX_DELAY);
  targetSpeed[MOTOR_FL] = constrain(y + x, -255, 255);
  targetSpeed[MOTOR_FR] = constrain(y - x, -255, 255);
  targetSpeed[MOTOR_BL] = constrain(y - x, -255, 255);
  targetSpeed[MOTOR_BR] = constrain(y + x, -255, 255);
  xSemaphoreGive(speedMutex);
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* server) override {
    deviceConnected = true;
  }
  void onDisconnect(BLEServer* server) override {
    deviceConnected = false;
    xSemaphoreTake(speedMutex, portMAX_DELAY);
    for (int i = 0; i < 4; i++) targetSpeed[i] = 0;
    xSemaphoreGive(speedMutex);
    BLEDevice::startAdvertising();
  }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* characteristic) override {
    String value = characteristic->getValue();
    if (value.length() < 3) return;

    uint8_t status = (uint8_t)value[0];
    uint8_t data1  = (uint8_t)value[1];
    uint8_t data2  = (uint8_t)value[2];
    //turn ON/OFF

    //front
    if (status == 177 && data1 == 0) {
      stickY = data2;
      updateMecanum();
    }
    //back
    else if (status == 176 && data1 == 0) {
      stickX = data2;
      updateMecanum();
    }
    //right turn
    else if (status == 176 && data1 == 34) {
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_FL] = -100;
      targetSpeed[MOTOR_BL] =  100;
      targetSpeed[MOTOR_FR] = -100;
      targetSpeed[MOTOR_BR] =  100;
      xSemaphoreGive(speedMutex);
    }
    //left turn
    else if (status == 177 && data1 == 34) {
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_FL] =  100;
      targetSpeed[MOTOR_BL] = -100;
      targetSpeed[MOTOR_FR] =  100;
      targetSpeed[MOTOR_BR] = -100;
      xSemaphoreGive(speedMutex);
    }
    //else if(status == 176 && data1 ==34){

    //}

    else if (status == 182 && data1 == 24){
        int angle = map(data2, 0, 127, 0, 180);
        _DODAI.write(angle);
    }
    else if (status == 177 && data1 == 15){
        int angle = map(data2, 0, 127, 0, 180);
        _Arm1.write(angle);
    }
    else if (status == 177 && data1 == 11){
        int angle = map(data2, 0, 127, 0, 180);
        _Arm2.write(angle);
    }
    else if (status == 177 && data1 == 19){
        int angle = map(data2, 0, 127, 0, 180);
        _HAND.write(angle);
    }

    else if(status == 148 && data1 == 99){
      ServoSET();
    }



    //全停止
    else if (status == 148 && data1 == 71) {
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      for (int i = 0; i < 4; i++) targetSpeed[i] = 0;
      xSemaphoreGive(speedMutex);
    }
  }
};
void ServoSET(){
  _HAND.write(90);
  _Arm1.write(90);
  _Arm2.write(90);
  _HAND.write(90);
}


void setup() {
  Serial.begin(115200);
  _DODAI.attach(Dodai);
  _Arm1.attach(Arm_1);
  _Arm2.attach(Arm_2);
  _HAND.attach(hand);

  speedMutex = xSemaphoreCreateMutex();

  for (uint8_t pin : pins) {
    ledcAttach(pin, 12800, 8);
    ledcWrite(pin, 0);
  }

  BLEDevice::init("ESP32-UART");
  Serial.print("BLE Address: ");
  Serial.println(BLEDevice::getAddress().toString().c_str());

  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService* service = server->createService(SERVICE_UUID);

  txCharacteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID_TX,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  txCharacteristic->addDescriptor(new BLE2902());

  BLECharacteristic* rxCharacteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID_RX,
    BLECharacteristic::PROPERTY_WRITE_NR
  );
  rxCharacteristic->setCallbacks(new RxCallbacks());

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->setMinPreferred(0x06);
  advertising->setMaxPreferred(0x12);
  BLEDevice::startAdvertising();

  Serial.println("Advertising Start");
  ServoSET();
}

void loop() {
  xSemaphoreTake(speedMutex, portMAX_DELAY);
  int spd[4];
  for (int i = 0; i < 4; i++) spd[i] = targetSpeed[i];
  xSemaphoreGive(speedMutex);

  for (int i = 0; i < 4; i++) {
    if (spd[i] != currentSpeed[i]) {
      currentSpeed[i] = spd[i];
      rotate(i, spd[i]);
    }
  }
  delay(1);
}