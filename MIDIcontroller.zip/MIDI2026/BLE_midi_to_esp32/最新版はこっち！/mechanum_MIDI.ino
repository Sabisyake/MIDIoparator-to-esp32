#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <freertos/semphr.h>
#include <ESP32Servo.h>

#define DODAI_PIN 12
#define ARM1_PIN 13
#define ARM2_PIN 23
#define HAND_PIN 22

Servo Dodai;
Servo Arm1;
Servo Arm2;
Servo Hand;


#define SERVICE_UUID           "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_RX "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_TX "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

enum MOTOR_ID { MOTOR_FL, MOTOR_BL, MOTOR_FR, MOTOR_BR , MOTOR_DX ,MOTOR_FB , MOTOR_MK };

constexpr uint8_t pins[] = {
  14, 27,   // FL
  26, 25,   // BL
  17, 16,   // FR
  33, 32,    // BR
  2,4,      // DX
  19,21,     // FB 19,21
  12,13     // MK 
};

BLECharacteristic *txCharacteristic;
SemaphoreHandle_t speedMutex;

volatile bool deviceConnected = false;
volatile int stickX = 63;
volatile int stickY = 63;
int targetSpeed[7] = {0, 0, 0, 0, 0, 0, 0};
int currentSpeed[7] = {999, 999, 999, 999, 999, 999, 999};

void rotate(uint8_t ID, int speed) {
  speed = constrain(speed, -255, 255);
  ledcWrite(pins[ID * 2],     speed > 0 ?  speed : 0);
  ledcWrite(pins[ID * 2 + 1], speed < 0 ? -speed : 0);
}

int midiToSpeed(uint8_t value) {
  int diff = (int)value - 63;
  if (abs(diff) <= 7) return 0;
  int sign = diff > 0 ? 1 : -1;
  return sign * map(abs(diff), 8, 63, 0, 255);
}

void updateMecanum() {
  int x = midiToSpeed(stickX);
  int y = midiToSpeed(stickY);

  xSemaphoreTake(speedMutex, portMAX_DELAY);
  targetSpeed[MOTOR_FL] = constrain(y + x, -255, 255);
  targetSpeed[MOTOR_FR] = constrain(y - x, -255, 255);
  targetSpeed[MOTOR_BL] = constrain(y - x, -255, 255);
  targetSpeed[MOTOR_BR] = constrain(y + x, -255, 255);

  xSemaphoreGive(speedMutex);
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* server) override {
    deviceConnected = true;
  }
  void onDisconnect(BLEServer* server) override {
    deviceConnected = false;
    xSemaphoreTake(speedMutex, portMAX_DELAY);
    for (int i = 0; i < 7; i++) targetSpeed[i] = 0;
    xSemaphoreGive(speedMutex);
    BLEDevice::startAdvertising();
  }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* characteristic) override {
    String value = characteristic->getValue();
    if (value.length() < 3) return;

    uint8_t status = (uint8_t)value[0];
    uint8_t data1  = (uint8_t)value[1];
    uint8_t data2  = (uint8_t)value[2];
    //turn ON/OFF

    //front
    if (status == 177 && data1 == 0) {
      stickY = data2;
      updateMecanum();
    }
    //back
    else if (status == 176 && data1 == 0) {
      stickX = data2;
      updateMecanum();
    }
    //right turn
    else if (status == 176 && data1 == 34 ) {
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_FL] = -100;
      targetSpeed[MOTOR_BL] =  100;
      targetSpeed[MOTOR_FR] = -100;
      targetSpeed[MOTOR_BR] =  100;
      xSemaphoreGive(speedMutex);
    }
    //left turn
    else if (status == 177 && data1 == 34) {
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_FL] =  100;
      targetSpeed[MOTOR_BL] = -100;
      targetSpeed[MOTOR_FR] =  100;
      targetSpeed[MOTOR_BR] = -100;
      xSemaphoreGive(speedMutex);
    }
    //左 (FB)
    else if(status == 153 && data1 == 0){
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_FB] = (data2 > 0) ? 255 : 0;
      xSemaphoreGive(speedMutex);
    }
    else if(status == 153 && data1 == 4){
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_FB] = (data2 > 0) ? -255 : 0;
      xSemaphoreGive(speedMutex);
    }
    //真ん中 (DX)
    else if(status == 153 && data1 == 1){
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_DX] = (data2 > 0) ? -255 : 0;
      xSemaphoreGive(speedMutex);
    }
    else if(status == 153 && data1 == 5){
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_DX] = (data2 > 0) ? 255 : 0;
      xSemaphoreGive(speedMutex);
    }
    //右 (MK)
    else if(status == 153 && data1 == 2){
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_MK] = (data2 > 0) ? 255 : 0;
      xSemaphoreGive(speedMutex);
    }
    else if(status == 153 && data1 == 6){
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      targetSpeed[MOTOR_MK] = (data2 > 0) ? -255 : 0;
      xSemaphoreGive(speedMutex);
    }
    else if (status == 182 && data1 == 24){
        int angle = map(data2, 0, 127, 0, 180);
        Dodai.write(angle);
    }
    else if (status == 177 && data1 == 15){
        int angle = map(data2, 0, 127, 0, 180);
        Arm1.write(angle);
    }
    else if (status == 177 && data1 == 11){
        int angle = map(data2, 0, 127, 0, 180);
        Arm2.write(angle);
    }
    else if (status == 177 && data1 == 19){
        int angle = map(data2, 0, 127, 0, 180);
        Hand.write(angle);
    }

    else if(status == 148 && data1 == 99){
      ServoSET();
    }



    //全停止
    else if (status == 148 && data1 == 71) {
      xSemaphoreTake(speedMutex, portMAX_DELAY);
      for (int i = 0; i < 7; i++) targetSpeed[i] = 0;
      xSemaphoreGive(speedMutex);
    }
  }
};
void ServoSET(){
  Hand.write(90);
  Arm1.write(90);
  Arm2.write(90);
  Dodai.write(90);
}


void setup() {
  Serial.begin(115200);
  Dodai.attach(DODAI_PIN);
  Arm1.attach(ARM1_PIN);
  Arm2.attach(ARM2_PIN);
  Hand.attach(HAND_PIN);

  speedMutex = xSemaphoreCreateMutex();

  for (uint8_t pin : pins) {
    ledcAttach(pin, 12800, 8);
    ledcWrite(pin, 0);
  }

  BLEDevice::init("ESP32-UART");
  Serial.print("BLE Address: ");
  Serial.println(BLEDevice::getAddress().toString().c_str());

  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService* service = server->createService(SERVICE_UUID);

  txCharacteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID_TX,
    BLECharacteristic::PROPERTY_NOTIFY
  );
  txCharacteristic->addDescriptor(new BLE2902());

  BLECharacteristic* rxCharacteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID_RX,
    BLECharacteristic::PROPERTY_WRITE_NR
  );
  rxCharacteristic->setCallbacks(new RxCallbacks());

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->setMinPreferred(0x06);
  advertising->setMaxPreferred(0x12);
  BLEDevice::startAdvertising();

  Serial.println("Advertising Start");
  ServoSET();

  xSemaphoreTake(speedMutex, portMAX_DELAY);
  targetSpeed[MOTOR_MK] = 0;
  xSemaphoreGive(speedMutex);
}

void loop() {
  xSemaphoreTake(speedMutex, portMAX_DELAY);
  int spd[7];
  for (int i = 0; i < 7; i++) spd[i] = targetSpeed[i];
  xSemaphoreGive(speedMutex);

  for (int i = 0; i < 7; i++) {
    if (spd[i] != currentSpeed[i]) {
      currentSpeed[i] = spd[i];
      rotate(i, spd[i]);
    }
  }
  delay(1);
}