import asyncio
from bleak import BleakScanner

async def scan_ble_devices():
    print("BLEデバイスをスキャン中... (5秒間)\n")
    
    results = await BleakScanner.discover(timeout=5.0, return_adv=True)
    
    if not results:
        print("デバイスが見つかりませんでした。")
        return
    
    print(f"{len(results)} 台のデバイスを発見:\n")
    
    items = list(results.values())
    items.sort(key=lambda x: x[1].rssi or -999, reverse=True)
    
    for device, adv in items:
        name = device.name or "(名前なし)"
        rssi = f"{adv.rssi} dBm" if adv.rssi else "不明"
        uuids = adv.service_uuids
        
        print(f"名前    : {name}")
        print(f"アドレス: {device.address}")
        print(f"RSSI    : {rssi}")
        if uuids:
            print(f"UUID    : {', '.join(uuids)}")
        else:
            print(f"UUID    : (なし / アドバタイズ未公開)")
        print("-" * 50)

asyncio.run(scan_ble_devices())