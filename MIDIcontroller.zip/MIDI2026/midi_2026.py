from bleak import BleakClient #ここのエラーは問題ないので無視
import rtmidi2
import asyncio

# 各デバイス名前の設定
MIDI_DEVICE_NAME = "DDJ-FLX4" #ここにつなげたいデバイスの名前を入力してください

# ---BLE_settings---
#MAC_ADDRESS  = "b0:cb:d8:c0:45:d2" #ESP32のMACアドレス入力.同梱のBLE_Checker.pyの結果から入力して下さい
#MAC_ADDRESS  = "00:4B:12:EE:F0:3A" 
#MAC_ADDRESS = "00:4B:12:EE:B6:52"
MAC_ADDRESS = "68:25:DD:33:CD:76"
SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
CHAR_UUID_RX = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
CHAR_UUID_TX = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

ble_client = None

midi_buffer = {}
last_Sent ={}


buffer_lock = asyncio.Lock()

# ---BLE受信---
def notification_handler(sender, data):
    print(f"ESP32から受信: {data.decode('utf-8', errors='replace')}")

# ---MIDI受信→バッファに積む---
def on_messages(message, timestamp):
    if ble_client and ble_client.is_connected:
        key = (message[0], message[1]) 
        midi_buffer[key] = message[2]   

# ---バッファを定期送信---
async def send_loop():
    while True:
        await asyncio.sleep(0.008)

        if not midi_buffer:
            continue
        if not (ble_client and ble_client.is_connected):
            continue
        snapshot = dict(midi_buffer)
        midi_buffer.clear()
        packet = bytearray()
        for (status, data1), data2 in snapshot.items():
            packet.extend([status, data1, data2])
        await ble_client.write_gatt_char(
            CHAR_UUID_RX,
            bytes(packet),
            response=False
        )
        print(f"{list(packet)}")

async def main():
    global ble_client

    # ---MIDI IN セットアップ---
    midi_in = rtmidi2.MidiIn()
    print("利用可能なMIDIポート:", midi_in.ports)

    try:
        index = midi_in.ports_matching(MIDI_DEVICE_NAME + "*")[0]
        midi_in.open_port(index)
        print(f"MIDIポート接続: {midi_in.ports[index]}")
    except IndexError:
        raise IOError(f"MIDIデバイス '{MIDI_DEVICE_NAME}' が見つかりません")

    midi_in.callback = on_messages

    # ---BLE接続---
    print(f"BLE接続中: {MAC_ADDRESS}")
    async with BleakClient(MAC_ADDRESS) as client:
        ble_client = client
        print(f"BLE接続成功: {client.is_connected}")

        await client.start_notify(CHAR_UUID_TX, notification_handler)

        print("MIDIを操作してください（Ctrl+C で終了）")
        try:
            await send_loop()
        except KeyboardInterrupt:
            print("終了します")

        await client.stop_notify(CHAR_UUID_TX)

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
loop.run_until_complete(main())